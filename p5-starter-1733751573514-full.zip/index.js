

function setup(){
  const canvas = createCanvas(100,100);
  canvas.parent("sketch");
  background("black");
}

function draw() {}
